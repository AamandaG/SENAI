import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.bundle.min.js'
import Rotas from "./routes"
import './css/global.css'
import './css/pg.css'

function App() {

  return (
    <>
      <Rotas/>
    </>
  )
}

export default App
