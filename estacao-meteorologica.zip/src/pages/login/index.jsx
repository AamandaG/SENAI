import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import '../../css/login.css';


export default function Login(){
    const [usuario, setUsuario] = useState('')
    const [senha, setSenha] = useState('')
    const navigate = useNavigate();

    const handleEntrar = (e) => {
        e.preventDefault();
        console.log('Usuario:', usuario, 'Senha:', senha);
        if(usuario && senha){
            console.log('Navegando para /principal');
            navigate('/principal');
        } else {
            alert('Preencha usuário e senha');
        }
    }

    
    return(
        <section className="container-login">
            
            <div className="login-form">
                <div className="form-box">

                    <h2>Login</h2>

                    <form onSubmit={handleEntrar}>

                        <div className="input-group">
                            <input 
                                type="text"
                                value={usuario}
                                onChange={(e) => setUsuario(e.target.value)}
                            />
                            <label>Usuário</label>
                        </div>

                        <div className="input-group">
                            <input 
                                type="password"
                                value={senha}
                                onChange={(e) => setSenha(e.target.value)}
                            />
                            <label>Senha</label>
                        </div>

                     <button 
                            className="btn-login"
                            type="submit"
                        >
                            Entrar
                        </button>

                       <p style={{textAlign: "center", marginTop: "10px"}}>
                            Não tem conta? <Link to="/cadastro">Criar conta</Link>
                        </p>

                    </form>

                </div>
            </div>

        </section>
    )
}