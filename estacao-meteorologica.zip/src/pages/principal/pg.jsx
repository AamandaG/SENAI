import Header from '../../components/header'
import '../../css/pg.css'

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';

import { Line } from 'react-chartjs-2';

// REGISTRAR COMPONENTES
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export default function Principal(){

    const leituras = [
       { estacao: 'Estação 1', temperatura: 25, umidade: 68 },
       { estacao: 'Estação 2', temperatura: 26, umidade: 54 },
       { estacao: 'Estação 3', temperatura: 23, umidade: 70 }
    ]

    const temperaturas = leituras.map(item => item.temperatura);
    const umidades = leituras.map(item => item.umidade);

    // 🎨 FUNÇÃO PARA DEFINIR COR
    function getCor(temp){
        if(temp <= 22) return '#313b76'; // azul escuro
        if(temp <= 25) return '#9f5894'; // azul claro
        return '#FF854D'; // laranja pastel
    }

const data = {
  labels: leituras.map(item => item.estacao),
  datasets: [
    {
      label: 'Temperatura (°C)',
      data: temperaturas,
      borderColor: '#FF854D',
      backgroundColor: 'rgba(255, 132, 77, 0.2)',
      tension: 0.4,
      fill: true,
      yAxisID: 'y',
      pointBackgroundColor: temperaturas.map(temp => getCor(temp)),
      pointRadius: 6
    },
    {
      label: 'Umidade (%)',
      data: umidades,
      borderColor: '#9a6cc0',
      backgroundColor: 'rgba(154, 108, 192, 0.2)',
      tension: 0.4,
      fill: true,
      yAxisID: 'y1',
      pointRadius: 5
    }
  ]
};

    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top'
            },
            title: {
                display: true,
                text: 'Temperatura por Estação'
            }
        },
        scales: {
            y: {
                type: 'linear',
                position: 'left',
                title: {
                    display: true,
                    text: 'Temperatura (°C)'
                },
                beginAtZero: true
            },
            y1: {
                type: 'linear',
                position: 'right',
                title: {
                    display: true,
                    text: 'Umidade (%)'
                },
                beginAtZero: true,
                grid: {
                    drawOnChartArea: false
                }
            }
        }
    };

    return(
        <>
            <Header/>
            <div className="home-container">

                <header className="home-header">
                    <h1>Bem-vindo!</h1>
                    <p>Seu sistema está funcionando perfeitamente</p>
                </header>

            <section className="cards">

                <div className="card">
                    <h3>Usuários</h3>
                    <p>Gerencie contas cadastradas</p>
                </div>

                <div className="card">
                    <h3>Relatórios</h3>
                    <p>Visualize dados do sistema</p>
                </div>

                <div className="card">
                    <h3>Configurações</h3>
                    <p>Personalize sua aplicação</p>
                </div>

            </section>

            <section className="grafico-principal">
                <h2>Temperaturas das Estações</h2>
                <div style={{ height: '350px', width: '100%' }}>
                    <Line data={data} options={options} />
                </div>
            </section>

        </div>
        </>
    )
}