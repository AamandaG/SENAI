import Header from '../../components/header'
import '../../css/relatorio.css'

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

import { Line } from 'react-chartjs-2';

// REGISTRAR COMPONENTES
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export default function Relatorio(){

    const leituras = [
       { horario: '12:00', temperatura: 25, umidade: 68 },
       { horario: '15:00', temperatura: 26, umidade: 54 },
       { horario: '17:00', temperatura: 23, umidade: 70 },
       { horario: '22:00', temperatura: 20, umidade: 72 }
    ]

    const temperaturas = leituras.map(item => item.temperatura);
    const umidades = leituras.map(item => item.umidade);

    // 🎨 FUNÇÃO PARA DEFINIR COR
    function getCor(temp){
        if(temp <= 22) return '#313b76'; // azul escuro
        if(temp <= 25) return '#9f5894'; // azul claro
        return '#FF854D'; // laranja pastel
    }

    const data = {
        labels: leituras.map(item => item.horario),
        datasets: [
            {
                label: 'Temperatura (°C)',
                data: temperaturas,
                tension: 0.4,
                borderWidth: 3,
                yAxisID: 'y',
                borderColor: (context) => {
                    const chart = context.chart;
                    const { ctx, chartArea } = chart;

                    if (!chartArea) return '#4a4e69';

                    const gradient = ctx.createLinearGradient(
                        0,
                        chartArea.top,
                        0,
                        chartArea.bottom
                    );

                    gradient.addColorStop(0, '#FF854D'); // quente
                    gradient.addColorStop(0.5, '#9a318a'); // médio
                    gradient.addColorStop(1, '#313b76'); // frio

                    return gradient;
                },
                pointBackgroundColor: temperaturas.map(temp =>
                    temp <= 22 ? '#4a4e69' :
                    temp <= 25 ? '#9a8c98' :
                    '#c9ada7'
                ),
                pointRadius: 6
            },
            {
                label: 'Umidade (%)',
                data: umidades,
                tension: 0.4,
                borderWidth: 2,
                yAxisID: 'y1',
                borderColor: '#9a6cc0',
                backgroundColor: '#8357a7',
                borderDash: [6, 6],
                pointRadius: 5
            }
        ]
    };

    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top'
            },
            title: {
                display: true,
                text: 'Temperatura e Umidade ao longo do tempo'
            }
        },
        scales: {
            y: {
                type: 'linear',
                position: 'left',
                title: {
                    display: true,
                    text: 'Temperatura (°C)'
                }
            },
            y1: {
                type: 'linear',
                position: 'right',
                title: {
                    display: true,
                    text: 'Umidade (%)'
                },
                grid: {
                    drawOnChartArea: false
                }
            }
        },
        elements: {
            line: {
                borderColor: (context) => {
                    const chart = context.chart;
                    const {ctx, chartArea} = chart;

                    if (!chartArea) return;

                    const gradient = ctx.createLinearGradient(0, 0, 0, chartArea.bottom);
                    gradient.addColorStop(0, '#FF854D');
                    gradient.addColorStop(1, '#313b76');
                    return gradient;
                }
            }
        }
    };


    return(
        <>
            <Header/>
            <div className='relatorio-container'>
                <h3>Relatório Estação de Leitura</h3><br/>
                <p>Monitorando dados de temperatura em tempo real</p>

                {/* 📈 GRÁFICO */}
                <section className='graficos'>
                    <Line data={data} options={options}/>
                </section>

                {/* 📋 TABELA */}
                <section className='tabela-leituras'>
                    <table>
                    <thead>
                        <tr>
                            <th>Horário</th>
                            <th>Temperatura</th>
                            <th>Umidade</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            leituras.map((item, index) => (
                                <tr key={index}>
                                     <td>{item.horario}</td>
                                     <td>{item.temperatura}°C</td>
                                     <td>{item.umidade}%</td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
                </section>
            </div>
        </>
    )

  }