import {Link} from 'react-router-dom';

export default function Header() {
    return (
        <header>
            <h2>Estação Meteorológica</h2>
            <nav>
                <ul>
                    <li><Link to="/principal">Home</Link></li>
                    <li><Link to="/relatorio">Relatorio</Link></li>
                    <li><Link to="/cadastro">Cadastro</Link></li>
                    <li><Link to="/">Sair</Link></li>
                </ul>
            </nav>
        </header>
    );
}